package com.neueda.interview.urlshortener.dto;

public class ShortUrl {

    private String shortUrl;

    public ShortUrl() {
    }

    public ShortUrl(String shortUrl) {
        this.shortUrl = shortUrl;
    }

    public String getShortUrl() {
        return shortUrl;
    }

    public void setShortUrl(String shortUrl) {
        this.shortUrl = shortUrl;
    }

}
