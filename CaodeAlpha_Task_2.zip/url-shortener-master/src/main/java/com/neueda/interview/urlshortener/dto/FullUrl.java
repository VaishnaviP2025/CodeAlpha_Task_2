package com.neueda.interview.urlshortener.dto;

public class FullUrl {

    private String fullUrl;

    public FullUrl() {
    }

    public FullUrl(String fullUrl) {
        this.fullUrl = fullUrl;
    }

    public String getFullUrl() {
        return fullUrl;
    }

    public void setFullUrl(String fullUrl) {
        this.fullUrl = fullUrl;
    }


}
